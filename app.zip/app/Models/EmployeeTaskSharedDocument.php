<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EmployeeTaskSharedDocument extends Model
{
    //
}
